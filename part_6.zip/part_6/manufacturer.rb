module Manufacturer
  attr_accessor :company
end