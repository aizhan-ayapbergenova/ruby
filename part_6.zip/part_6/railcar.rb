require_relative 'manufacturer'

class RailCar
  include Manufacturer
end