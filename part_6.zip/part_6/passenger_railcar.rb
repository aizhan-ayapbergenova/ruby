class PassengerRailcar < RailCar
end