module Validator

  ATTR_NAME = /[\w]/
  NUMBER_FORMAT = /^[\w]{3}[\w]{2}|[\w]{3}-[\w]{2}$/i

  def name_valid?
    validate!(name)
  rescue
    false
  end

  def number_valid?
    number_validate!
  rescue
    false
  end

  protected

  def name_validate!(name)
    raise 'Enter the name' if name.length == 0
    raise 'The name is incorrect' if name !~ ATTR_NAME
    true
  end

  def number_validate!
    raise "The train number must have letters or numbers and look like this: XXX-XX or XXXXX" if number !~ NUMBER_FORMAT
    true
  end
end