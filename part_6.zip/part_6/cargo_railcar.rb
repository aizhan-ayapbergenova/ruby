class CargoRailcar < RailCar
end